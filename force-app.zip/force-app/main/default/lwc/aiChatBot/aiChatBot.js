import { LightningElement, track }
from 'lwc';
import SALESFORCE_LOGO
from '@salesforce/resourceUrl/SalesforceLogo';
import getAIResponse
from '@salesforce/apex/GroqController.getAIResponse';

export default class AiChatBot
extends LightningElement {

    @track messages = [];
    logoUrl = SALESFORCE_LOGO;
    userInput = '';

    isLoading = false;

    handleChange(event){

        this.userInput =
            event.target.value;
    }

    handleKeyPress(event){

        if(event.keyCode === 13){

            this.sendMessage();
        }
    }

    async sendMessage(){

        if(!this.userInput){
            return;
        }

        this.messages = [
            ...this.messages,
            {
                id: Date.now(),
                sender: 'You',
                text: this.userInput,
                cssClass: 'user-message',
                wrapperClass: 'user-wrapper'
            }
        ];

        const userQuestion =
            this.userInput;

        this.userInput = '';

        this.isLoading = true;

        this.scrollBottom();

        try{

            const response =
                await getAIResponse({
                    userMessage:
                    userQuestion
                });

            this.messages = [
                ...this.messages,
                {
                    id: Date.now() + 1,
                    sender: 'SF-AI',
                    text: this.formatResponse(response),
                    cssClass: 'bot-message',
                    wrapperClass: 'bot-wrapper'
                }
            ];

        }catch(error){

            this.messages = [
                ...this.messages,
                {
                    id: Date.now() + 2,
                    sender: 'SF-AI',
                    text: 'Something went wrong.',
                    cssClass: 'bot-message',
                    wrapperClass: 'bot-wrapper'
                }
            ];

            console.error(error);
        }

        this.isLoading = false;

        this.scrollBottom();
    }

    renderedCallback(){

        this.renderMessages();
    }

    renderMessages(){

        const containers =
            this.template.querySelectorAll(
                '.message-text'
            );
    
        containers.forEach((container, index) => {
    
            if(this.messages[index]){
    
                container.innerHTML =
                    this.messages[index].text;
            }
        });
    }

    formatResponse(text){

        if(!text){
            return '';
        }
    
        let formatted =
            text
    
            /* Code blocks */
    
            .replace(
                /```([\s\S]*?)```/g,
                '<pre class="code-block"><code>$1</code></pre>'
            )
    
            /* Bold */
    
            .replace(
                /\*\*(.*?)\*\*/g,
                '<b>$1</b>'
            )
    
            /* Line breaks */
    
            .replace(
                /\n/g,
                '<br/>'
            );
    
        return formatted;
    }

    scrollBottom(){

        setTimeout(() => {

            const chatBody =
                this.template.querySelector(
                    '.chat-body'
                );

            if(chatBody){

                chatBody.scrollTop =
                    chatBody.scrollHeight;
            }

        }, 100);
    }
}